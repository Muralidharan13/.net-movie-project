# DotNet_Movies-Page
This is an ASP.NET Web application for movies.
This application is created using ASP.NET Core, C#, SQL Server and Entity Framework Core.
1. You can Create new movie.
2. You can go to the Movies Information section and see all movies.
3. In the Movies Information section you can Select a movie a see the information about the movie, like: Title, Year and Genre.
4. You can Edit the selected movie.
5. You can Delete the selected movie.
