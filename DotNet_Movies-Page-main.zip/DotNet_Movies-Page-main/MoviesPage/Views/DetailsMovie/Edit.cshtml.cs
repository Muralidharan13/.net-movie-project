using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MoviesPage.Views.DetailsMovie
{
    public class EditModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
